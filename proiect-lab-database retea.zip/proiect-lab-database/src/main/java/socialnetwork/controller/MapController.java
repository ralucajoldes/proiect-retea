package socialnetwork.controller;

import javafx.scene.layout.AnchorPane;

public class MapController
{

    public AnchorPane anchor;

}
