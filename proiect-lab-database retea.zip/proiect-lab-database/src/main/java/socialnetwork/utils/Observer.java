package socialnetwork.utils;

public interface Observer
{
    public void execute_update();
}
