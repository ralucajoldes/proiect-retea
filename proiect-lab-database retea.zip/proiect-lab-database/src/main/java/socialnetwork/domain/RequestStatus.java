package socialnetwork.domain;

public enum RequestStatus
{
    PENDING,APPROVED,REJECTED,CANCELED;
}
